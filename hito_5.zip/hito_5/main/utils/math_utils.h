#pragma once
#include <stdint.h>

uint8_t calculate_light_level(float resistance);

